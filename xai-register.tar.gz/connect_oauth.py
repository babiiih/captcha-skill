"""Connect xAI accounts to 9Router — one-by-one manual OAuth."""
import sys
sys.path = [p for p in sys.path if "hermes-agent" not in p]

from pathlib import Path
from curl_cffi import requests as cffi
import requests as std_requests
import time
import json

ROUTER_BASE = "http://localhost:20128"
ROUTER_TOKEN = Path(r"E:\hermes\projects\xai-9router-register\9r_current_token.txt").read_text().strip()
ACCOUNTS_FILE = Path(r"E:\hermes\projects\xai-9router-register\accounts.txt")

def get_device_code():
    """Get OAuth device code from 9Router."""
    resp = std_requests.get(
        f"{ROUTER_BASE}/api/oauth/grok-cli/device-code",
        cookies={"auth_token": ROUTER_TOKEN},
        timeout=15,
    )
    if resp.status_code != 200:
        print(f"  ✗ 9router error: {resp.status_code}")
        return None
    return resp.json()

def poll_9router(device_code, code_verifier):
    """Poll 9Router for completed OAuth."""
    resp = std_requests.post(
        f"{ROUTER_BASE}/api/oauth/grok-cli/poll",
        json={"deviceCode": device_code, "codeVerifier": code_verifier, "extraData": None},
        cookies={"auth_token": ROUTER_TOKEN},
        headers={"Accept": "*/*", "Content-Type": "application/json"},
        timeout=15,
    )
    return resp.status_code == 200

def main():
    accounts = []
    for line in ACCOUNTS_FILE.read_text().strip().split("\n"):
        parts = line.split("|")
        if len(parts) >= 5:
            accounts.append({"email": parts[0], "pass": parts[1], "name": parts[2]})
    
    print(f"📋 Total akun: {len(accounts)}")
    print()
    
    for i, acc in enumerate(accounts, 1):
        print(f"\n{'='*50}")
        print(f"[{i}/{len(accounts)}] {acc['email']} — {acc['name']}")
        print(f"{'='*50}")
        
        # Get device code
        data = get_device_code()
        if not data:
            continue
        
        verify_url = data.get("verification_uri_complete") or data.get("verificationUriComplete")
        device_code = data.get("device_code") or data.get("deviceCode")
        code_verifier = data.get("codeVerifier") or data.get("code_verifier")
        user_code = data.get("user_code") or data.get("userCode")
        
        print(f"\n🔗 Buka link ini di Chrome, login & APPROVE:")
        print(f"   {verify_url}")
        print(f"\n📋 Kalo perlu login:")
        print(f"   Email:    {acc['email']}")
        print(f"   Password: {acc['pass']}")
        print(f"\n⏳ Setelah approve, Nara akan polling...")
        
        # Poll 60 detik
        for attempt in range(30):
            time.sleep(2)
            if poll_9router(device_code, code_verifier):
                print(f"  ✅ Akun {acc['email']} TERHUBUNG ke 9Router!")
                # Update accounts.txt
                break
            if attempt % 5 == 4:
                print(f"  ... menunggu approve ({attempt+1}/30)")
        else:
            print(f"  ❌ Timeout — skip")

if __name__ == "__main__":
    main()
