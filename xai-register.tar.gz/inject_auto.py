"""Auto-inject xAI accounts to 9Router via headed Chrome."""
import sys
sys.path = [p for p in sys.path if "hermes-agent" not in p]

from pathlib import Path
import requests as std_requests
import time
from playwright.sync_api import sync_playwright

ROUTER_BASE = "http://localhost:20128"
ROUTER_TOKEN = Path(r"E:\hermes\projects\xai-9router-register\9r_current_token.txt").read_text().strip()
ACCOUNTS_FILE = Path(r"E:\hermes\projects\xai-9router-register\accounts.txt")

accounts = []
for line in ACCOUNTS_FILE.read_text().strip().split("\n"):
    parts = line.split("|")
    if len(parts) >= 5:
        accounts.append({"email": parts[0], "pass": parts[1], "name": parts[2]})

print(f"📋 Total: {len(accounts)} akun")
connected = 0

for i, acc in enumerate(accounts, 1):
    print(f"\n{'='*50}")
    print(f"[{i}/{len(accounts)}] {acc['email']}")
    
    # 1. Get device code from 9Router
    resp = std_requests.get(
        f"{ROUTER_BASE}/api/oauth/grok-cli/device-code",
        cookies={"auth_token": ROUTER_TOKEN}, timeout=15,
    )
    if resp.status_code != 200:
        print(f"  ✗ 9Router error: {resp.status_code}")
        continue
    
    data = resp.json()
    verify_url = data.get("verification_uri_complete")
    device_code = data.get("device_code")
    code_verifier = data.get("codeVerifier")
    
    print(f"  🔐 Buka Chrome...")
    
    # 2. Open browser and do OAuth
    approved = False
    try:
        with sync_playwright() as pw:
            browser = pw.chromium.launch(
                headless=True,
                channel="chrome",
                args=[
                    "--disable-blink-features=AutomationControlled",
                    "--no-first-run",
                    "--no-default-browser-check",
                ],
            )
            context = browser.new_context(
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36",
                locale="en-US",
            )
            page = context.new_page()
            
            try:
                # Go to OAuth URL
                page.goto(verify_url, wait_until="domcontentloaded", timeout=20_000)
                time.sleep(2)
                
                # Try to login: fill email
                try:
                    email_el = page.wait_for_selector('input[type="email"]', timeout=5_000)
                    if email_el:
                        email_el.fill(acc["email"])
                        time.sleep(0.5)
                        # Click Continue
                        cont = page.query_selector('button:has-text("Continue")')
                        if cont:
                            cont.click()
                            time.sleep(2)
                        
                        # Fill password
                        pw_el = page.query_selector('input[type="password"]')
                        if pw_el:
                            pw_el.fill(acc["pass"])
                            time.sleep(0.5)
                            # Click Sign In
                            signin = page.query_selector('button:has-text("Sign in")')
                            if signin:
                                signin.click()
                                time.sleep(3)
                except:
                    pass
                
                # Click Allow
                try:
                    allow = page.wait_for_selector('button:has-text("Allow")', timeout=10_000)
                    if allow:
                        allow.click()
                        time.sleep(2)
                        approved = True
                except:
                    print(f"  ⚠ No Allow button found")
                    
            except Exception as e:
                print(f"  ⚠ Browser error: {e}")
            
            context.close()
            browser.close()
    except Exception as e:
        print(f"  ⚠ Playwright error: {e}")
    
    # 3. Poll 9Router
    if approved:
        time.sleep(3)
    
    ok = False
    for s in range(30):
        time.sleep(1)
        try:
            poll = std_requests.post(
                f"{ROUTER_BASE}/api/oauth/grok-cli/poll",
                json={"deviceCode": device_code, "codeVerifier": code_verifier, "extraData": None},
                cookies={"auth_token": ROUTER_TOKEN},
                headers={"Accept": "*/*", "Content-Type": "application/json"},
                timeout=5,
            )
            if poll.status_code == 200:
                ok = True
                break
        except:
            pass
    
    if ok:
        print(f"  ✅ Terhubung ke 9Router!")
        connected += 1
    else:
        print(f"  ❌ Gagal terhubung")

print(f"\n{'='*50}")
print(f"✅ {connected}/{len(accounts)} terhubung ke 9Router")
