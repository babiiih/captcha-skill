"""Wrapper for xai_register that patches camoufox to use E: drive browser."""
import sys
from pathlib import Path

# 1) Filter hermes-agent from path
sys.path = [p for p in sys.path if "hermes-agent" not in p]

# 2) Set INSTALL_DIR in the camoufox module BEFORE importing it
E_CACHE = Path(r"E:\tmp\camoufox-home\cache")
BROWSERS = E_CACHE / "browsers"

import camoufox.pkgman as _pm
import camoufox.multiversion as _mv

# Re-run the path initialization for pkgman
_pm.INSTALL_DIR = E_CACHE
_pm.BROWSERS_DIR = BROWSERS
_pm.CONFIG_FILE = E_CACHE / "config.json"  # in pkgman too
_mv.INSTALL_DIR = E_CACHE
_mv.BROWSERS_DIR = BROWSERS
_mv.CONFIG_FILE = E_CACHE / "config.json"

# 3) Write config + version.json if needed
import orjson

cfg = {"active_version": "browsers/official/135.0.1-beta.24"}
E_CACHE.mkdir(parents=True, exist_ok=True)
_mv.CONFIG_FILE.write_bytes(orjson.dumps(cfg, option=orjson.OPT_INDENT_2))

ver_dir = E_CACHE / "browsers" / "official" / "135.0.1-beta.24"
vj = ver_dir / "version.json"
if not vj.exists():
    vj.write_bytes(orjson.dumps({
        "build": "beta.24", "version": "135.0.1", "prerelease": True,
        "sha256": "dummy", "created_at": "2026-07-23",
    }, option=orjson.OPT_INDENT_2))

# 4) Verify
print("[wrapper] camoufox path:", _pm.launch_path(), file=sys.stderr)
print("[wrapper] ready!", file=sys.stderr)

# 5) Run
import xai_register
sys.exit(xai_register.main())
