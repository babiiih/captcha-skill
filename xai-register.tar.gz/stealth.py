"""Stealth init script for Playwright — copied from CloakBrowser's stealth.py"""
import json

STEALTH_SCRIPT = r"""
(() => {
  // --- webdriver ---
  try { Object.defineProperty(Navigator.prototype, 'webdriver', { get: () => undefined, configurable: true }); } catch(e) {}
  try { delete Navigator.prototype.webdriver; } catch(e) {}

  // --- plugins ---
  try { Object.defineProperty(Navigator.prototype, 'plugins', { get: () => [1,2,3,4,5], configurable: true }); } catch(e) {}

  // --- languages ---
  try { Object.defineProperty(Navigator.prototype, 'languages', { get: () => ['en-US','en'], configurable: true }); } catch(e) {}

  // --- platform ---
  try { Object.defineProperty(Navigator.prototype, 'platform', { get: () => 'Win32', configurable: true }); } catch(e) {}

  // --- hardwareConcurrency ---
  try { Object.defineProperty(Navigator.prototype, 'hardwareConcurrency', { get: () => 8, configurable: true }); } catch(e) {}

  // --- deviceMemory ---
  try { Object.defineProperty(Navigator.prototype, 'deviceMemory', { get: () => 8, configurable: true }); } catch(e) {}

  // --- chrome runtime ---
  try { window.chrome = { runtime: {}, loadTimes: function(){}, csi: function(){} }; } catch(e) {}

  // --- permissions ---
  try {
    const origQuery = window.navigator.permissions.query;
    window.navigator.permissions.query = (p) => (
      p.name === 'notifications' ? Promise.resolve({state: 'denied'}) : origQuery(p)
    );
  } catch(e) {}

  // --- WebGL vendor ---
  try {
    const getExt = WebGLRenderingContext.prototype.getExtension;
    WebGLRenderingContext.prototype.getExtension = function(name) {
      if (name.includes('WEBGL_debug_renderer_info')) return null;
      return getExt.call(this, name);
    };
  } catch(e) {}

  // --- screen ---
  try {
    Object.defineProperty(Screen.prototype, 'width', { get: () => 1920 });
    Object.defineProperty(Screen.prototype, 'height', { get: () => 1080 });
    Object.defineProperty(Screen.prototype, 'availWidth', { get: () => 1920 });
    Object.defineProperty(Screen.prototype, 'availHeight', { get: () => 1040 });
    Object.defineProperty(Screen.prototype, 'colorDepth', { get: () => 24 });
    Object.defineProperty(Screen.prototype, 'pixelDepth', { get: () => 24 });
  } catch(e) {}
})();
"""

def get_stealth_script():
    return STEALTH_SCRIPT
