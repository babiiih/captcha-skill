"""Connect xAI accounts to 9Router — show URLs, poll, then continue."""
import sys
sys.path = [p for p in sys.path if "hermes-agent" not in p]

from pathlib import Path
import requests as std_requests
import time

ROUTER_BASE = "http://localhost:20128"
ROUTER_TOKEN = Path(r"E:\hermes\projects\xai-9router-register\9r_current_token.txt").read_text().strip()
ACCOUNTS_FILE = Path(r"E:\hermes\projects\xai-9router-register\accounts.txt")

accounts = []
for line in ACCOUNTS_FILE.read_text().strip().split("\n"):
    parts = line.split("|")
    if len(parts) >= 5:
        accounts.append({"email": parts[0], "pass": parts[1], "name": parts[2]})

print(f"📋 Total: {len(accounts)} akun")
print()

for i, acc in enumerate(accounts, 1):
    print(f"\n{'='*50}")
    print(f"[{i}/{len(accounts)}] {acc['email']} — {acc['name']}")
    
    # Get device code
    resp = std_requests.get(
        f"{ROUTER_BASE}/api/oauth/grok-cli/device-code",
        cookies={"auth_token": ROUTER_TOKEN}, timeout=15,
    )
    if resp.status_code != 200:
        print(f"  ✗ 9Router error: {resp.status_code}")
        continue
    
    data = resp.json()
    verify_url = data.get("verification_uri_complete") or data.get("verificationUriComplete")
    device_code = data.get("device_code") or data.get("deviceCode")
    code_verifier = data.get("codeVerifier") or data.get("code_verifier")
    
    print(f"\n  🔗 BUKA link ini di Chrome:")
    print(f"     {verify_url}")
    print(f"\n  📋 Login kalo diminta:")
    print(f"     Email:    {acc['email']}")
    print(f"     Password: {acc['pass']}")
    print(f"\n  ⏳ Polling 1 menit...")
    
    # Poll for up to 60 seconds
    ok = False
    for s in range(60):
        time.sleep(1)
        if s % 10 == 0:
            print(f"     ... menunggu approve ({s+1}/60)", end="\r", flush=True)
        try:
            poll = std_requests.post(
                f"{ROUTER_BASE}/api/oauth/grok-cli/poll",
                json={"deviceCode": device_code, "codeVerifier": code_verifier, "extraData": None},
                cookies={"auth_token": ROUTER_TOKEN},
                headers={"Accept": "*/*", "Content-Type": "application/json"},
                timeout=5,
            )
            if poll.status_code == 200:
                ok = True
                break
        except:
            pass
    
    print()
    if ok:
        print(f"  ✅ TERHUBUNG ke 9Router!")
    else:
        print(f"  ❌ Tidak terhubung (timeout)")

print(f"\n{'='*50}")
print(f"Selesai! ✅ {sum(1 for a in accounts)} diproses")
